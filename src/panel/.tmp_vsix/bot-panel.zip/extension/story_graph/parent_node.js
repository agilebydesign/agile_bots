class ParentNode {
    constructor(nodeType, nodeName) {
        this.node_type = nodeType;
        this.node_name = nodeName;
    }
}

module.exports = ParentNode;
